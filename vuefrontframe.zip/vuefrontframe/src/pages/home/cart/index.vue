<template>
    <div>购物车</div>
</template>

<script>
    export default {
        mounted(){
            document.title=this.$route.meta.title
        }
    }
</script>

<style scoped>

</style>
