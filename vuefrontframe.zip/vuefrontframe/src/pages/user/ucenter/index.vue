<template>
    <div>会员中心</div>
</template>

<script>
    export default {
        mounted(){
            document.title=this.$route.meta.title
        }
    }
</script>

<style scoped>

</style>
