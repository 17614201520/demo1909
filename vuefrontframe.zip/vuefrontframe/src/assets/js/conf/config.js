let config={
    baseApi:process.env.VUE_APP_API
};
export default config;
